package com.mobile2app.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.mobile2app.R;
import com.mobile2app.activities.CreateActivity;
import com.mobile2app.activities.EditActivity;
import com.mobile2app.activities.LoginActivity;
import com.mobile2app.activities.MainActivity;
import com.mobile2app.models.WeightEntry;

import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.WeightViewHolder> {
    private Context mCtx;
    private List<WeightEntry> weightList;

    public WeightEntryAdapter(Context mCtx, List<WeightEntry>  weightList) {
        this.mCtx = mCtx;
        this. weightList =  weightList;
    }

    @NonNull
    @Override
    public WeightEntryAdapter.WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.recyclerview_weight, parent, false);
        return  new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        final WeightEntry weightEntry = weightList.get(position);
        holder.gained.append(String.valueOf(weightEntry.getWeightGained())+" lbs");
        holder.lost.append(String.valueOf(weightEntry.getWeightLost())+" lbs");
        holder.goal.append(String.valueOf(weightEntry.getWeightGoal())+" lbs");
        holder.date.append(weightEntry.getDate());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
                builder.setMessage("Are you sure you want to DELETE this item ?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                builder.show();
            }
        });

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mCtx, EditActivity.class);
                intent.putExtra("id",String.valueOf(weightEntry.getId()));
                mCtx.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return weightList.size();
    }

    class WeightViewHolder extends RecyclerView.ViewHolder{
        TextView gained,lost,goal,date;
        Button edit,delete;
        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            gained = itemView.findViewById(R.id.weight_gained);
            lost = itemView.findViewById(R.id.weight_lost);
            goal = itemView.findViewById(R.id.weight_goal);
            date = itemView.findViewById(R.id.weight_date);
            edit = itemView.findViewById(R.id.edit_weight);
            delete = itemView.findViewById(R.id.delete_weight);
        }
    }
}
