package com.mobile2app.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.mobile2app.models.User;

public class NewLifeDB extends Helper {

    public NewLifeDB(Context context) {
        super(context);
    }

    public User resisterUser(String userName, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        User user = new User();
        user.setUsername(userName);
        user.setPassword(password);
        ContentValues values = user.getContentValuesToAdd();
        Long id = db.insert("users", null, values);
        db.close();
        return user;
    }


    public String userLogin(String userName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query("users", null, " username=?", new String[]{userName}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex("password"));
        cursor.close();
        return password;
    }


}
