package com.mobile2app.models;

import java.util.Date;

public class WeightEntry {
    private int id,weightGained,weightLost,weightGoal;
    private String date;

    public WeightEntry(){

    }

    public WeightEntry(int id, int weightGained, int weightLost, int weightGoal, String date) {
        this.id = id;
        this.weightGained = weightGained;
        this.weightLost = weightLost;
        this.weightGoal = weightGoal;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public int getWeightGained() {
        return weightGained;
    }

    public int getWeightLost() {
        return weightLost;
    }

    public int getWeightGoal() {
        return weightGoal;
    }

    public String getDate() {
        return date;
    }


    //setters


    public void setId(int id) {
        this.id = id;
    }

    public void setWeightGained(int weightGained) {
        this.weightGained = weightGained;
    }

    public void setWeightLost(int weightLost) {
        this.weightLost = weightLost;
    }

    public void setWeightGoal(int weightGoal) {
        this.weightGoal = weightGoal;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
