package com.mobile2app.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mobile2app.classes.AlarmReceiver;
import com.mobile2app.R;
import com.mobile2app.adapters.WeightEntryAdapter;
import com.mobile2app.database.MyDatabaseHelper;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.models.Weight;
import com.mobile2app.storage.SharePreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightEntryAdapter adapter;
    private List<Weight> weightList = new ArrayList<>();
  private Button logout_button;
  private FloatingActionButton add_button;
    public static final String NOTIFICATION_CHANNEL_ID = "10001" ;
    private final static String default_notification_channel_id = "default" ;
    NewLifeDB newLifeDB;
    FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newLifeDB = new NewLifeDB(this);
        MyDatabaseHelper dbh = new MyDatabaseHelper(MainActivity.this);

        logout_button=findViewById(R.id.logout_button);
        add_button = findViewById(R.id.add_button);



        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,CreateActivity.class);
                startActivity(intent);
            }
        });


        logout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutUser();
            }
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("weights/"+SharePreferenceManager.getInstance(MainActivity.this).getUser().getUsername());

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                weightList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    Weight weight = ds.getValue(Weight.class);
                    System.out.println(weight.getDate().toString());
                    weightList.add(weight);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter = new WeightEntryAdapter(MainActivity.this, weightList);
                            recyclerView.setAdapter(adapter);
                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };

        myRef.addValueEventListener(postListener);



    }

    @Override
    protected void onStart() {
        super.onStart();

        if (!SharePreferenceManager.getInstance(this).isLoggedIn()) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }

        if(!SharePreferenceManager.getInstance(this).isPermission()){
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setMessage("NEW LIFE would like to show Notifications. Please Grant or Deny Permission to continue.")
                    .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                           SharePreferenceManager.getInstance(MainActivity.this).savePermissionStatus(1);
                            scheduleNotification(getNotification( "Congratulations! You will receive instant notifications from this Application." ) , 5000 );
                        }
                    })
                    .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            SharePreferenceManager.getInstance(MainActivity.this).savePermissionStatus(0);
                        }
                    });
            builder.show();
        }

    }

    private void logoutUser() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Are you sure you want to logout from this App?")
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SharePreferenceManager.getInstance(MainActivity.this).logout();
                       Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                       startActivity(intent);
                       finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        builder.show();

    }

    private void scheduleNotification (Notification notification , int delay) {
        Intent notificationIntent = new Intent( this, AlarmReceiver. class ) ;
        notificationIntent.putExtra(AlarmReceiver. NOTIFICATION_ID , 1 ) ;
        notificationIntent.putExtra(AlarmReceiver. NOTIFICATION , notification) ;
        PendingIntent pendingIntent = PendingIntent. getBroadcast ( this, 0 , notificationIntent , PendingIntent. FLAG_UPDATE_CURRENT ) ;
        long futureInMillis = SystemClock. elapsedRealtime () + delay ;
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context. ALARM_SERVICE ) ;
        assert alarmManager != null;
        alarmManager.set(AlarmManager. ELAPSED_REALTIME_WAKEUP , futureInMillis , pendingIntent) ;
    }
    private Notification getNotification (String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder( this, default_notification_channel_id ) ;
        builder.setContentTitle( "New Life Notification" ) ;
        builder.setContentText(content) ;
        builder.setSmallIcon(R.drawable. ic_launcher_foreground ) ;
        builder.setAutoCancel( true ) ;
        builder.setChannelId( NOTIFICATION_CHANNEL_ID ) ;
        return builder.build() ;
    }

    }



