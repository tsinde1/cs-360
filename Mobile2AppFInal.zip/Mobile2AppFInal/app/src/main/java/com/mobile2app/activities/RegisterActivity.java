package com.mobile2app.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobile2app.R;
import com.mobile2app.database.Helper;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.models.User;

public class RegisterActivity extends AppCompatActivity {
private Button to_login,create;
Helper helper;
NewLifeDB newLifeDB;
private EditText username,password,cpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        newLifeDB = new NewLifeDB(this);
        username =findViewById(R.id.txtUsername);
        password = findViewById(R.id.txtPassword);
        cpassword = findViewById(R.id.c_password);

        to_login=findViewById(R.id.to_login);
        create=findViewById(R.id.create);

        to_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(login);
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!password.getText().toString().trim().equals(cpassword.getText().toString().trim())){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(RegisterActivity.this,"Passwords do not match. Please try again.",Toast.LENGTH_LONG).show();
                        }
                    });

                    return;
                }
                User user = newLifeDB.resisterUser(username.getText().toString(),password.getText().toString());
                Log.d("Username ",user.getUsername());
                Log.d("Password",user.getPassword());
                if(!user.getUsername().equals("") || !user.getPassword().equals("")){
                    Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(RegisterActivity.this,"Account not created! Please try again.",Toast.LENGTH_LONG).show();
                        }
                    });
                }

            }
        });
    }
}