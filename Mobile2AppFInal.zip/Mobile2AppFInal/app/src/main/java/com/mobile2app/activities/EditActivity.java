package com.mobile2app.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobile2app.R;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.models.Weight;
import com.mobile2app.storage.SharePreferenceManager;

import java.util.HashMap;

public class EditActivity extends AppCompatActivity {
String id,weightGained,weightLost,weighGoal,date;

EditText weightGai,weightL,weightGoal,wdate;
    NewLifeDB newLifeDB;
    Button update;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        newLifeDB = new NewLifeDB(this);
        weightGai = findViewById(R.id.eweightGained);
        weightL = findViewById(R.id.eweightLos);
        weightGoal = findViewById(R.id.eweightGoal);
        wdate = findViewById(R.id.c_date);

        update = findViewById(R.id.updateBtn);

        Intent intent = getIntent();
        if(intent!=null){
            id = intent.getStringExtra("id");
            weightGained = intent.getStringExtra("gained");
            weightLost = intent.getStringExtra("lost");
            weighGoal = intent.getStringExtra("goal");
            date = intent.getStringExtra("date");

            weightGai.append(weightGained);
            weightL.append(weightLost);
            weightGoal.append(weighGoal);
            wdate.append(date);
        }

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("weights/"+ SharePreferenceManager
                        .getInstance(EditActivity.this).getUser().getUsername()+"/"+id);

                HashMap<String,Object> data = new HashMap<>();
                data.put("gained",weightGai.getText().toString());
                data.put("lost",weightL.getText().toString());
                data.put("goal",weightGoal.getText().toString());
                data.put("date",wdate.getText().toString());

                myRef.updateChildren(data).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(EditActivity.this,"Record updated successfully!",Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

            }
        });


    }
}