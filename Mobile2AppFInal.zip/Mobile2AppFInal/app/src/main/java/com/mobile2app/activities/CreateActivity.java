package com.mobile2app.activities;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobile2app.R;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.models.Weight;
import com.mobile2app.storage.SharePreferenceManager;

import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

public class CreateActivity extends AppCompatActivity {
    EditText userWeightGain, userWeightLoss, userWeightGoal, mDate;
    Calendar myCalendar;
    Button create;
    NewLifeDB newLifeDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        newLifeDB = new NewLifeDB(this);
        myCalendar = Calendar.getInstance();
        create = findViewById(R.id.createBtn);

        userWeightGain = findViewById(R.id.userWeightGained);
        userWeightLoss = findViewById(R.id.userWeightLost);
        userWeightGoal = findViewById(R.id.userWeightGoal);
        mDate = findViewById(R.id.c_date);


        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        mDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(CreateActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {

                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                saveNewEntry(userWeightGoal.getText().toString(), userWeightLoss.getText().toString(), userWeightGain.getText().toString(), sdf.format(myCalendar.getTime()));


            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mDate.setText(sdf.format(myCalendar.getTime()));
    }

    private void saveNewEntry(String goalWeight, String lostWeight, String gainedWeight, String date) {

        final ProgressDialog progress = new ProgressDialog(CreateActivity.this);
        progress.setTitle("Loading");
        progress.setMessage("Wait while loading...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.show();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("weights");


        Random random = new Random();

        int id = random.nextInt(10000) + 10;

        Weight weight = new Weight(String.valueOf(id), lostWeight, gainedWeight, goalWeight, date);


        myRef.child(SharePreferenceManager.getInstance(CreateActivity.this).getUser()
                .getUsername()).child(String.valueOf(id)).setValue(weight).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progress.dismiss();
                        Toast.makeText(CreateActivity.this, "New Entry has been added successfully.", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });


    }
}