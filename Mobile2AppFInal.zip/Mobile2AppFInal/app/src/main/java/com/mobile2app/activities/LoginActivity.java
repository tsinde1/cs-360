package com.mobile2app.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobile2app.R;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.storage.SharePreferenceManager;

public class LoginActivity extends AppCompatActivity {
    private Button login,sign_mail;
    private View register;
    NewLifeDB newLifeDB;
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        newLifeDB = new NewLifeDB(this);
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);
        sign_mail= findViewById(R.id.sign_mail);

        username = findViewById(R.id.editTextUserName);
        password = findViewById(R.id.editTextUserPassword);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName= username.getText().toString();
                String Password= password.getText().toString();
                if(userName.equals("") || Password.equals("")){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(LoginActivity.this,"Username or Password field cannot be blank!",Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                String storedPassword=newLifeDB.userLogin(userName);
                if (Password.equals(storedPassword)){

                    SharePreferenceManager.getInstance(LoginActivity.this).saveUser(userName,Password);
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(LoginActivity.this,"Wrong username or password",Toast.LENGTH_LONG).show();
                        }
                    });
                }

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent register_intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(register_intent);
            }
        });

        sign_mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(LoginActivity.this,"Coming Soon ...",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(SharePreferenceManager.getInstance(this).isLoggedIn()){
            Intent intent = new Intent(LoginActivity.this,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }
}